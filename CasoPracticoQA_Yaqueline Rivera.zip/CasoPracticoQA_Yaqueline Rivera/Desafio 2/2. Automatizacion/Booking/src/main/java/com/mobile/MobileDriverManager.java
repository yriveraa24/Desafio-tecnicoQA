package com.mobile;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;


public class MobileDriverManager {
    private static AppiumDriver<MobileElement> driver;

    public static AppiumDriver<MobileElement> getDriver() {
        return driver;
    }

    public static void initMobileDriver() {
        DesiredCapabilities desiredCapabilities = new DesiredCapabilities();
        desiredCapabilities.setCapability("automationName", "UiAutomator2");
        desiredCapabilities.setCapability("platformName", "Android");
        desiredCapabilities.setCapability("deviceName", "Pixel 2");
        desiredCapabilities.setCapability("platformVersion", "11");
        desiredCapabilities.setCapability("appActivity", "com.booking.startup.HomeActivity");
        desiredCapabilities.setCapability("appPackage", "com.booking");
        desiredCapabilities.setCapability("noReset", true);
        desiredCapabilities.setCapability("fullReset", false);
        desiredCapabilities.setCapability("autoGrantPermissions", true);
        //  desiredCapabilities.setCapability("clearSystemFiles",true);
        //  desiredCapabilities.setCapability("locationServicesAuthorized", false);
        //  desiredCapabilities.setCapability("locationServicesEnabled", false);

        try {
            driver = new AndroidDriver<>(new URL("http://0.0.0.0:4723/wd/hub/"), desiredCapabilities);
            driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
        } catch (MalformedURLException malformedURLException) {
            Logger.getLogger(MobileDriverManager.class.getName()).log(Level.WARNING, "Ocurrio un error en la formación de URL");
        }
    }

    public static void quitDriver() {
        driver.quit();
    }
}
