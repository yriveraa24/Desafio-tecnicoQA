package com.bdd.view;

import io.appium.java_client.MobileElement;
import io.appium.java_client.TouchAction;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.touch.offset.ElementOption;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;


import java.util.List;

import static com.mobile.MobileDriverManager.getDriver;


public class ViewBooking {

    private String valoresperado;

    public ViewBooking() {
        PageFactory.initElements(new AppiumFieldDecorator(getDriver()), this);
    }


    @AndroidFindBy(xpath = "(//android.widget.Button)[1]")
    private MobileElement gestionarDestino;
    @AndroidFindBy(xpath = "//android.widget.EditText")
    private MobileElement ingresardestino;
    @AndroidFindBy(xpath = "(//android.widget.TextView)[1]")
    private MobileElement selecDestino;
    @AndroidFindBy(id = "touch_outside")
    private MobileElement elegirfecha;
    @AndroidFindBy(xpath = "(//android.widget.Button)[2]")
    private MobileElement gestionarFecha;
    @AndroidFindBy(id = "facet_date_picker_selection_summary")
    private MobileElement totalDias;
    @AndroidFindBy(id = "facet_date_picker_confirm")
    private MobileElement btnseleccionarFechas;
    @AndroidFindBy(xpath = "(//android.widget.Button)[3]")
    private MobileElement gestionarHabitacion;
    @AndroidFindBy(xpath = "(//android.widget.TextView[@resource-id=\"com.booking:id/bui_input_stepper_value\"])[1]")
    private MobileElement nroHabitacion;
    @AndroidFindBy(xpath = "(//android.widget.Button[@content-desc=\"Subir\"])[1]")
    private MobileElement seleccionarHabitacion;
    @AndroidFindBy(xpath = "//android.widget.TextView[@resource-id=\"com.booking:id/bui_input_stepper_value\" and @text=\"2\"]")
    private MobileElement nroAdulto;
    @AndroidFindBy(xpath = "(//android.widget.Button[@content-desc=\"Subir\"])[2]")
    private MobileElement seleccionarAdulto;
    @AndroidFindBy(xpath = "(//android.widget.Button[@content-desc=\"Subir\"])[3]")
    private MobileElement seleccionarNiño;
    @AndroidFindBy(id = "bui_input_container_background")
    private MobileElement seleccionarEdad;
    @AndroidFindBy(xpath = "//android.widget.EditText[@resource-id=\"android:id/numberpicker_input\"]")
    private MobileElement edad;
    @AndroidFindBy(xpath = "//android.widget.Button[@resource-id=\"android:id/button1\"]")
    private MobileElement btnEdadOK;
    @AndroidFindBy(id = "group_config_apply_button")
    private MobileElement btnAplicar;
    @AndroidFindBy(xpath = "//android.view.View[@content-desc=\"Cuadro de búsqueda de alojamiento\"]/android.view.View/android.widget.Button")
    private MobileElement btnBuscar;
    @AndroidFindBy(xpath = "(//android.view.View[@content-desc=\"Eliminar\"])[1]")
    private MobileElement eliminaraviso;
    @AndroidFindBy(xpath = "//android.view.View[@resource-id=\"sr_list\"]/android.view.View[2]")
    private MobileElement Item2;
    @AndroidFindBy(id = "select_room_cta")
    private MobileElement btnEligeHabitacion;

    @AndroidFindBy(xpath = "//android.widget.TextView[@text=\"SELECCIONAR\"]")
    private MobileElement opcionHabitacion;

    @AndroidFindBy(xpath = "(//android.widget.TextView)[2]")
    private MobileElement elegirApartamento;

    @AndroidFindBy(id = "room_pref_select2")
    private MobileElement btnReservarAhora;

    @AndroidFindBy(xpath = "(//android.widget.EditText)[1]")
    private MobileElement campoNombre;

    @AndroidFindBy(xpath = "(//android.widget.EditText)[2]")
    private MobileElement campoApellido;

    @AndroidFindBy(xpath = "(//android.widget.EditText)[3]")
    private MobileElement campoEmail;

    @AndroidFindBy(xpath = "(//android.widget.EditText)[4]")
    private MobileElement campoPais;

    @AndroidFindBy(xpath = "(//android.widget.EditText)[5]")
    private MobileElement campoTelefono;

    @AndroidFindBy(xpath = "//android.widget.Button")
    private MobileElement btnSiguientePaso;

    @AndroidFindBy(xpath = "//android.widget.TextView[@text=\"Último paso\"]")
    private MobileElement btnUltimoPaso;

    @AndroidFindBy(id = "new_credit_card_number_edit")
    private MobileElement campoNroTarjeta;

    @AndroidFindBy(xpath = "(//android.widget.EditText)[2]")
    private MobileElement titularTarjeta;

    @AndroidFindBy(id = "new_credit_card_expiry_date_edit")
    private MobileElement campoFechaCaducidad;

    @AndroidFindBy(id = "new_credit_card_cvc_edit_text")
    private MobileElement campocvc;

    @AndroidFindBy(xpath = "//androidx.compose.ui.platform.ComposeView[@resource-id=\"com.booking:id/bp_bottom_bar_compose_view\"]/android.view.View/android.view.View/android.view.View[2]/android.widget.Button")
    private MobileElement bntReservar;

    @AndroidFindBy(xpath = "(//android.widget.TextView)[2]")
    private MobileElement mensajeConfirmacion;


    public void IntroduceDestino() {

        gestionarDestino.click();
    }

    public void escriboDestino(String xDestino) {

        ingresardestino.sendKeys(xDestino);
    }

    public void seleccionoElDestino() {
        selecDestino.click();
    }

    public void seleccionarFechaInicio(String fechaInicio) {
        elegirfecha.click();
        gestionarFecha.click();
        MobileElement elementToDrag = getDriver().findElement(By.xpath("//android.view.ViewGroup[@resource-id=\"com.booking:id/month_container\"]"));
// Determina las coordenadas iniciales y finales para la acción de arrastrar
        int startX = elementToDrag.getLocation().getX();
        int startY = elementToDrag.getLocation().getY();
        int endX = startX; // Misma coordenada X que el elemento
        int endY = startY - 540; // Mueve 100 píxeles hacia arriba
// Crea una instancia de TouchAction
        TouchAction touchAction = new TouchAction(getDriver());
// Realiza la acción de presionar y arrastrar
        touchAction.longPress(ElementOption.element(elementToDrag))
                .moveTo(ElementOption.point(endX, endY))
                .release()
                .perform();

        MobileElement selectInicio = getDriver().findElement(By.xpath("//android.view.View[@content-desc='" + fechaInicio + "']"));
        selectInicio.click();
    }


    public void seleccionarFechaFin(String fechaFin) {
        MobileElement selectInicio = getDriver().findElement(By.xpath("//android.view.View[@content-desc='" + fechaFin + "']"));
        selectInicio.click();
    }

    public void validarDiasdeAlojamiento() {

        String cantNoches = "13 noches";
        Assert.assertTrue("Error en la cantidad de noches", totalDias.getText().contains(cantNoches));
    }

    public void presionarbotonSeleccionarFechas() {
        btnseleccionarFechas.click();
    }

    public void seleccionarHabitacionYPersonas() {
        gestionarHabitacion.click();
    }

    public void seleccionarHabitacion() {
        String habitacion = nroHabitacion.getText();
        if (habitacion.equals("0")) {
            seleccionarHabitacion.click();
        } else {
            Assert.assertTrue(true);
        }
    }

    public void seleccionarAdultos() {
        String adulto = nroAdulto.getText();
        if (adulto.equals("1")) {
            seleccionarAdulto.click();
        } else {
            Assert.assertTrue(true);
        }
    }

    public void seleccionarNiño() {
        seleccionarNiño.click();
    }

    public void seleccionarEdadNiño() {
        seleccionarEdad.click();
        MobileElement elementToDrag = getDriver().findElement(By.xpath("//android.widget.Button[@text=\"menos de 1 año\"]"));
// Determina las coordenadas iniciales y finales para la acción de arrastrar
        int startX = elementToDrag.getLocation().getX();
        int startY = elementToDrag.getLocation().getY();
        int endX = startX; // Misma coordenada X que el elemento
        int endY = startY - 1000; // Mueve 100 píxeles hacia arriba
// Crea una instancia de TouchAction
        TouchAction touchAction = new TouchAction(getDriver());
// Realiza la acción de presionar y arrastrar
        touchAction.longPress(ElementOption.element(elementToDrag))
                .moveTo(ElementOption.point(endX, endY))
                .release()
                .perform();
        edad.click();
    }

    public void presionoOK() {
        btnEdadOK.click();
    }

    public void presionarAplicar() {
        btnAplicar.click();
    }

    public void validarDatosDeBusqueda() {
        String destinoelegido = gestionarDestino.getAttribute("content-desc");
        String fechaelegida = gestionarFecha.getAttribute("content-desc");
        String habitacionelegida = gestionarHabitacion.getAttribute("content-desc");
        String destino = "Cusco";
        String fecha = "Alojarse del mié., 01 may. al mar., 14 may";
        String habitacion = "1 habitación, 2 adultos, 1 niño";

        Assert.assertTrue("No coincide con el destino elegido", destinoelegido.contains(destino));
        Assert.assertTrue("No coincide con la fecha elegida", fechaelegida.contains(fecha));
        Assert.assertTrue("No coincide con la habitacion elegida", habitacionelegida.contains(habitacion));

    }

    public void presionarBuscar() {
        btnBuscar.click();
    }

    public void validarResultadosDeBusqueda() {
        MobileElement resultados = getDriver().findElementByXPath("//android.view.View[@resource-id=\"sr_list\"]");
        Assert.assertNotNull("No se muestran resultados", resultados);
    }

    public void seleccionarItem() {
        MobileElement elementToDrag = getDriver().findElement(By.xpath("//android.view.View[@resource-id=\"sr_list\"]/android.view.View[1]"));
// Determina las coordenadas iniciales y finales para la acción de arrastrar
        int startX = elementToDrag.getLocation().getX();
        int startY = elementToDrag.getLocation().getY();
        int endX = startX; // Misma coordenada X que el elemento
        int endY = startY - 400; // Mueve 100 píxeles hacia arriba
// Crea una instancia de TouchAction
        TouchAction touchAction = new TouchAction(getDriver());
// Realiza la acción de presionar y arrastrar
        touchAction.longPress(ElementOption.element(elementToDrag))
                .moveTo(ElementOption.point(endX, endY))
                .release()
                .perform();

        MobileElement aviso = getDriver().findElementByXPath("//android.view.View[@resource-id=\"sr_list\"]/android.view.View[5]");
        if (aviso.isDisplayed()) {
            eliminaraviso.click();
            Item2.click();
        } else {
            Item2.click();
        }


    }

    public void presionarElegirHabitacion() {
        btnEligeHabitacion.click();
    }

    public void ElegirHabitacion() {
        MobileElement elementToDrag = getDriver().findElement(By.xpath("(//android.widget.TextView)[2]"));
// Determina las coordenadas iniciales y finales para la acción de arrastrar
        int startX = elementToDrag.getLocation().getX();
        int startY = elementToDrag.getLocation().getY();
        int endX = startX; // Misma coordenada X que el elemento
        int endY = startY - 100; // Mueve 100 píxeles hacia arriba
// Crea una instancia de TouchAction
        TouchAction touchAction = new TouchAction(getDriver());
// Realiza la acción de presionar y arrastrar
        touchAction.longPress(ElementOption.element(elementToDrag))
                .moveTo(ElementOption.point(endX, endY))
                .release()
                .perform();
    }

    public void presionoSeleccionar() {
        opcionHabitacion.click();
    }


    public void validarCostoReserva() {
        MobileElement elemento = getDriver().findElementByXPath("//android.widget.TextView[@resource-id=\"com.booking:id/info_title\"]");
        valoresperado = elemento.getText();
        Assert.assertNotNull("No se muestran el costo de habitacion", valoresperado);
        // System.out.println("Texto capturado: " + valoresperado);
    }

    public void presionarReservarAhora() {
        validarCostoReserva();
        elegirApartamento.click();
        btnReservarAhora.click();
        MobileElement datoCosto = getDriver().findElementByXPath("(//android.view.ViewGroup/android.widget.LinearLayout/android.widget.TextView)[3]");
        String costomostrado = datoCosto.getText();
        //System.out.println("costo extraido: " + valoresperado);
        //System.out.println("Texto mostrado: " + costomostrado);
        Assert.assertEquals("El costo de la reserva es el esperado", valoresperado, costomostrado);
    }

    public void validoPantallaDeIngresoDatos() {
        MobileElement pantallaDatos = getDriver().findElementByXPath("//android.widget.TextView[@text=\"Introducir datos\"]");
        Assert.assertNotNull("No se muestra la pantalla Introducir Datos", pantallaDatos);
    }

    public void validarDatosCliente() {
        Assert.assertTrue(!campoNombre.getText().isEmpty());
        Assert.assertTrue(!campoApellido.getText().isEmpty());
        Assert.assertTrue(!campoEmail.getText().isEmpty());
        Assert.assertTrue(!campoPais.getText().isEmpty());
        Assert.assertTrue(!campoTelefono.getText().isEmpty());
    }

    public void validarCostoEnIntroducirDatos() {
        validarCostoReserva();
        MobileElement datoCosto = getDriver().findElementByXPath("(//androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View/android.view.View/android.widget.TextView)[2]]");
        String costomostrado = datoCosto.getText();
        Assert.assertEquals("El costo de la reserva es el esperado", valoresperado, costomostrado);
    }

    public void presionarSiguientePaso() {
        btnSiguientePaso.click();
    }

    public void validarCostoEnPantallaResumen() {
        validarCostoReserva();
        MobileElement datoCosto = getDriver().findElementByXPath("(//androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View/android.view.View/android.widget.TextView)[2]]");
        String costomostrado = datoCosto.getText();
        Assert.assertEquals("El costo de la reserva es el esperado", valoresperado, costomostrado);
    }

    public void presionarUltimoPaso() {
        btnUltimoPaso.click();
    }

    public void validarPantallaTerminarReserva() {
        MobileElement terminarReserva = getDriver().findElementByXPath("//android.widget.TextView[@text=\"Terminar reserva\"]");
        Assert.assertNotNull("No se muestra la pantalla Terminar Reserva", terminarReserva);

    }

    public void registroElNumeroDeTarjetaValido(String xNrotarjeta) {
        campoNroTarjeta.sendKeys(xNrotarjeta);
    }

    public void validarNombreTitular() {
        Assert.assertTrue(!titularTarjeta.getText().isEmpty());
    }

    public void registroLaFechaDeCaducidad(String fechaCaducidad) {
        campoFechaCaducidad.sendKeys(fechaCaducidad);
    }

    public void registroElCódigoCVC(String cvc) {
        MobileElement campoCVC = getDriver().findElementById("new_credit_card_cvc_edit_text");
        if (campoCVC.isDisplayed()) {
            campocvc.sendKeys(cvc);
        } else {
            Assert.assertTrue(true);
        }
    }

    public void validarCostoEnPantallaTerminar() {
        validarCostoReserva();
        MobileElement datoCosto = getDriver().findElementByXPath("(//androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View/android.view.View/android.widget.TextView)[1]");
        String costomostrado = datoCosto.getText();
        Assert.assertEquals("El costo de la reserva es el esperado", valoresperado, costomostrado);

    }

    public void presionarReservarAhoraFinal() {
        bntReservar.click();
    }

    public void validoLaReservaExitosa() {
        WebDriverWait wait = new WebDriverWait(getDriver(), 30);
        By confirmacion = By.xpath("//android.widget.TextView[@text=\"Tu reserva está confirmada\"]");
        wait.until(ExpectedConditions.visibilityOfElementLocated(confirmacion));
        String mensajeConfirmado = "Confirmada";
        Assert.assertTrue("No coincide con el destino elegido", mensajeConfirmacion.getText().contains(mensajeConfirmado));
    }

}