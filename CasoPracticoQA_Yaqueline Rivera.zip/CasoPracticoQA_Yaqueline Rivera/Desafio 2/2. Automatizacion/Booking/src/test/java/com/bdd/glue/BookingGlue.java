package com.bdd.glue;

import com.bdd.step.BookingStep;
import com.mobile.MobileDriverManager;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class BookingGlue {
    private BookingStep bookingStep;

    @Before
    public void beforeScenario() {
        bookingStep = new BookingStep();
    }

    @After
    public void afterScenario() {
        MobileDriverManager.quitDriver();
    }

    @Given("accedo al aplicativo")
    public void AccedoAlAplicativo() {
        MobileDriverManager.initMobileDriver();
    }

    @When("presiono el campo Introduce destino")
    public void presionoElCampoIntroduceDestino() {
        bookingStep.presionoElCampoIntroduceDestino();
    }

    @And("escribo el destino {string}")
    public void escriboElDestino(String xDestino) {
        bookingStep.escriboDestino(xDestino);
    }

    @Then("selecciono el destino elegido")
    public void seleccionoElDestinoElegido() {
        bookingStep.seleccionoElDestinoElegido();
    }

    @And("selecciono las fechas estadia {string} a {string}")
    public void seleccionoLasFechasEstadia(String FechaInicio, String FechaFin) {
        bookingStep.seleccionoLasFechasEstadia(FechaInicio, FechaFin);
    }

    @Then("valido los dias de alojamiento en la parte inferior")
    public void validoLosDiasDeAlojamientoEnLaParteInferior() {
        bookingStep.validoLosDiasDeAlojamientoEnLaParteInferior();
    }

    @And("presiono el boton Seleccionar fechas")
    public void presionoElBotonSeleccionarFechas() {
        bookingStep.presionoElBotonSeleccionarFechas();
    }

    @When("presiono el campo Selecciona las habitaciones y las personas")
    public void presionoElCampoSeleccionaLasHabitacionesYLasPersonas() {
        bookingStep.presionoElCampoSeleccionaLasHabitacionesYLasPersonas();
    }

    @And("selecciono una Habitacion")
    public void seleccionoUnaHabitacion() {
        bookingStep.seleccionoUnaHabitacion();
    }

    @And("selecciono dos Adultos")
    public void seleccionoDosAdultos() {
        bookingStep.seleccionoDosAdultos();
    }


    @And("selecciono un Niño de 5 años$")
    public void seleccionoUnNiñoDe5Años() {
        bookingStep.seleccionoUnNiño();
    }

    @And("presiono OK")
    public void presionoOK() {
        bookingStep.presionoOK();
    }

    @And("presiono el boton Aplicar")
    public void presionoElBotonAplicar() {
        bookingStep.presionoElBotonAplicar();
    }

    @Then("valido los datos ingresados para la busqueda")
    public void validoLosDatosIngresadosParaLaBusqueda() {
        bookingStep.validoLosDatosIngresadosParaLaBusqueda();
    }

    @And("presiono el boton Buscar")
    public void presionoElBotonBuscar() {
        bookingStep.presionoElBotonBuscar();
    }

    @When("valido los resultados de la busqueda")
    public void validoLosResultadosDeLaBusqueda() {
        bookingStep.validoLosResultadosDeLaBusqueda();
    }

    @Then("selecciono el item 2 de la lista$")
    public void seleccionoElItemDeLaLista() {
        bookingStep.seleccionoElItemDeLaLista();
    }

    @And("presiono el boton Elige habitacion")
    public void presionoElBotonEligeHabitacion() {
        bookingStep.presionoElBotonEligeHabitacion();
    }

    @When("elijo la primera opcion de habitaciones")
    public void elijoLaPrimeraOpcionDeHabitaciones() {
        bookingStep.elijoLaPrimeraOpcionDeHabitaciones();
    }

    @And("presiono seleccionar")
    public void presionoSeleccionar() {
        bookingStep.presionoSeleccionar();
    }

    @Then("valido el costo de la reserva")
    public void validoElCostoDeLaReserva() {
        bookingStep.validoElCostoDeLaReserva();

    }

    @And("presiono el boton Reservar ahora")
    public void presionoElBotonReservarAhora() {
        bookingStep.presionoElBotonReservarAhora();
    }

    @When("me encuentro en la pantalla Introducir datos")
    public void meEncuentroEnLaPantallaIntroducirDatos() {
        bookingStep.meEncuentroEnLaPantallaIntroducirDatos();
    }

    @And("valido que se carguen los datos del cliente que reserva")
    public void validoQueSeCarguenLosDatosDelClienteQueReserva() {
        bookingStep.validoQueSeCarguenLosDatosDelClienteQueReserva();
    }

    @And("valido el costo de la reserva en pantalla Introducir datos")
    public void validoElCostoDeLaReservaEnPantallaIntroducirDatos() {
        bookingStep.validoElCostoDeLaReservaEnPantallaIntroducirDatos();
    }

    @And("presiono el boton Siguiente paso")
    public void presionoElBotonSiguientePaso() {
        bookingStep.presionoElBotonSiguientePaso();
    }

    @And("valido el costo de la reserva en la pantalla Resumen de reserva")
    public void validoElCostoDeLaReservaEnLaPantallaResumenDeReserva() {
        bookingStep.validoElCostoDeLaReservaEnLaPantallaResumenDeReserva();
    }

    @And("selecciono el boton Ultimo paso")
    public void seleccionoElBotonUltimoPaso() {
        bookingStep.seleccionoElBotonUltimoPaso();
    }

    @When("me encuentro en la pantalla Terminar reserva")
    public void meEncuentroEnLaPantallaTerminarReserva() {
        bookingStep.meEncuentroEnLaPantallaTerminarReserva();
    }


    @And("registro el numero de tarjeta valido {string}")
    public void registroElNumeroDeTarjetaValido(String xNrotarjeta) {
        bookingStep.registroElNumeroDeTarjetaValido(xNrotarjeta);
    }

    @And("valido el nombre del titular de la tarjeta")
    public void validoElNombreDelTitularDeLaTarjeta() {
        bookingStep.validoElNombreDelTitularDeLaTarjeta();
    }

    @And("registro la fecha de caducidad {string}")
    public void registroLaFechaDeCaducidad(String fechaCaducidad) {
        bookingStep.registroLaFechaDeCaducidad(fechaCaducidad);
    }

    @And("registro el código CVC {string}")
    public void registroElCódigoCVC(String cvc) {
        bookingStep.registroElCódigoCVC(cvc);
    }

    @And("valido el costo de la reserva en la pantalla Terminar reserva")
    public void validoElCostoDeLaReservaEnLaPantallaTerminarReserva() {
        bookingStep.validoElCostoDeLaReservaEnLaPantallaTerminarReserva();
    }

    @And("presiono el boton Reservar ahora final")
    public void presionoElBotonReservarAhoraFinal() {
        bookingStep.presionoElBotonReservarAhoraFinal();
    }

    @Then("valido la reserva exitosa")
    public void validoLaReservaExitosa() {
        bookingStep.validoLaReservaExitosa();
    }
}
