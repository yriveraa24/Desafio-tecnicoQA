package com.bdd.step;

import com.bdd.view.ViewBooking;
import org.junit.jupiter.api.Assertions;

public class BookingStep {
    public ViewBooking viewBooking() {
        return new ViewBooking();
    }

    public void presionoElCampoIntroduceDestino() {
        viewBooking().IntroduceDestino();
    }

    public void escriboDestino(String xDestino) {
        viewBooking().escriboDestino(xDestino);
    }

    public void seleccionoElDestinoElegido() {
        viewBooking().seleccionoElDestino();
    }


    public void seleccionoLasFechasEstadia(String fechaInicio, String fechaFin) {
        viewBooking().seleccionarFechaInicio(fechaInicio);
        viewBooking().seleccionarFechaFin(fechaFin);
    }

    public void validoLosDiasDeAlojamientoEnLaParteInferior() {
        viewBooking().validarDiasdeAlojamiento();
    }

    public void presionoElBotonSeleccionarFechas() {
        viewBooking().presionarbotonSeleccionarFechas();
    }

    public void presionoElCampoSeleccionaLasHabitacionesYLasPersonas() {
        viewBooking().seleccionarHabitacionYPersonas();
    }

    public void seleccionoUnaHabitacion() {
        viewBooking().seleccionarHabitacion();
    }

    public void seleccionoDosAdultos() {
        viewBooking().seleccionarAdultos();
    }

    public void seleccionoUnNiño() {
        viewBooking().seleccionarNiño();
        viewBooking().seleccionarEdadNiño();
    }

    public void presionoOK() {
        viewBooking().presionoOK();
    }

    public void presionoElBotonAplicar() {
        viewBooking().presionarAplicar();
    }

    public void validoLosDatosIngresadosParaLaBusqueda() {
        viewBooking().validarDatosDeBusqueda();
    }

    public void presionoElBotonBuscar() {
        viewBooking().presionarBuscar();
    }

    public void validoLosResultadosDeLaBusqueda() {
        viewBooking().validarResultadosDeBusqueda();
    }

    public void seleccionoElItemDeLaLista() {
        viewBooking().seleccionarItem();
    }

    public void presionoElBotonEligeHabitacion() {
        viewBooking().presionarElegirHabitacion();
    }

    public void elijoLaPrimeraOpcionDeHabitaciones() {
        viewBooking().ElegirHabitacion();
    }

    public void presionoSeleccionar() {viewBooking().presionoSeleccionar();}

    public void validoElCostoDeLaReserva() {
        viewBooking().validarCostoReserva();
    }

    public void presionoElBotonReservarAhora() {
        viewBooking().presionarReservarAhora();
    }

    public void meEncuentroEnLaPantallaIntroducirDatos() {
        viewBooking().validoPantallaDeIngresoDatos();
    }

    public void validoQueSeCarguenLosDatosDelClienteQueReserva() {
        viewBooking().validarDatosCliente();
    }

    public void validoElCostoDeLaReservaEnPantallaIntroducirDatos() {
        viewBooking().validarCostoEnIntroducirDatos();
    }

    public void presionoElBotonSiguientePaso() {
        viewBooking().presionarSiguientePaso();
    }

    public void validoElCostoDeLaReservaEnLaPantallaResumenDeReserva() {viewBooking().validarCostoEnPantallaResumen();}

    public void seleccionoElBotonUltimoPaso() {
        viewBooking().presionarUltimoPaso();
    }

    public void meEncuentroEnLaPantallaTerminarReserva() {
        viewBooking().validarPantallaTerminarReserva();
    }

    public void registroElNumeroDeTarjetaValido(String xNrotarjeta) {
        viewBooking().registroElNumeroDeTarjetaValido(xNrotarjeta);
    }

    public void validoElNombreDelTitularDeLaTarjeta() {
        viewBooking().validarNombreTitular();
    }

    public void registroLaFechaDeCaducidad(String fechaCaducidad) {
        viewBooking().registroLaFechaDeCaducidad(fechaCaducidad);
    }

    public void registroElCódigoCVC(String cvc) {
        viewBooking().registroElCódigoCVC(cvc);
    }

    public void validoElCostoDeLaReservaEnLaPantallaTerminarReserva() {
        viewBooking().validarCostoEnPantallaTerminar();
    }

    public void presionoElBotonReservarAhoraFinal() {
        viewBooking().presionarReservarAhoraFinal();
    }

    public void validoLaReservaExitosa() {
        viewBooking().validoLaReservaExitosa();
    }

}
