package com.bdd.runner;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import org.junit.runner.RunWith;

@RunWith(Cucumber.class)
@CucumberOptions(
        glue = "com.bdd.glue",
        features = "src/test/resources/features/ReservaBooking.feature",
        stepNotifications = true,
        tags = "@CP01"
)
public class RunnerTest {

}
